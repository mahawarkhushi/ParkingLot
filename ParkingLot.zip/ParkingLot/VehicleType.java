public enum VehicleType {
    CAR, BIKE, TRUCK
}
